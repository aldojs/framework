
'use strict'

const { APP_NAME, APP_ENV, APP_URL } = process.env

/**
 * The application name
 *
 * @type {String}
 */
exports.name = APP_NAME || 'Test App'

/**
 * The application environment
 *
 * @type {String}
 */
exports.env = APP_ENV || 'development'

/**
 * The application URL
 *
 * @type {String}
 */
exports.url = APP_URL || 'http://localhost'

/**
 * The application timezone
 *
 * @type {String}
 */
exports.timezone = 'UTC'

/**
 * The application locale
 *
 * @type {String}
 */
exports.locale = 'en'
