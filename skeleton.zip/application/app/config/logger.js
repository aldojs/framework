
'use strict'

/**
 * Default logger writer
 *
 * @type {String}
 */
exports.default = 'console'

/**
 * @type {Object}
 */
exports.loggers = {
  'console': {
    //
  }
}
