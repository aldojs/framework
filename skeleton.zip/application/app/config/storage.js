
'use strict'

let { join } = require('path')

/**
 * Default Filesystem disk
 *
 * @type {String}
 */
exports.default = 'temp'

/**
 * Supported Filesystem disks
 *
 * @type {Object}
 */
exports.disks = {
  'temp': {
    disk: 'local',
    root: _resolve('temp')
  }
}

/**
 * Return the absolute path of the storage directory
 * 
 * @param {String} dir 
 * @private
 */
function _resolve (dir) {
  return join(__dirname, '../storage', dir)
}
