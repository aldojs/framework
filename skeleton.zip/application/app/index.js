
import { Application } from '@aldo/application'

let services = [
  // load the configuration first (required)
  'config',

  // load app file systems (required by logger, session)
  'storage',

  // load global logger (optional)
  'logger',

  // cookie parsing service (required by session)
  'cookies',

  // init session (optional, could be required by auth)
  'session',

  // (optional)
  // 'auth',

  // load the app routes (optional)
  'routes'
]

/**
 * Create and initialize a basic application
 * 
 * @public
 */
export async function createApplication () {
  let app = new Application()

  // install services
  for (let file of services) {
    let service = require('./services/' + file)

    await service.install(app, __dirname)
  }

  return app
}
