
'use strict'

const { Router } = require('../../lib')

const router = module.exports = new Router()

router.get('/', ({ response }, next) => {
  response.body = 'hello buddy!'
  // next(new Error('dkfld'))
  next()
})
