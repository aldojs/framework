
import { join } from 'path'
import { statSync } from 'fs'
import { Loader } from '@aldo/config'

export function install (app, root) {
  let loader = new Loader()
  let folder = join(root, 'config')

  // load all files
  let store = loader.load(folder)

  let path = join(folder, store.get('app.env'))

  // merge with environment config
  if (_isDirectory(path)) {
    store.merge(loader.load(path))
  }

  // set the app configuration
  app.set('config', store)
}

/**
 * Check if the given path is a folder
 * 
 * @param {String} path
 * @returns {Boolean}
 * @private
 */
function _isDirectory (path) {
  return statSync(path).isDirectory()
}
