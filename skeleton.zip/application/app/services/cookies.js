
import { Cookies } from '@aldo/cookie'
import { createResponse } from '@aldo/http'

export function install (app) {
  // bind the cookies jar
  app.bind('cookies', ({ request }) => new Cookies(request.headers.cookie))

  // attach the middleware
  app.use(async ({ cookies }, next) => {
    let response = createResponse(await next())

    return response.setCookie(cookies.toHeader())
  })
}
