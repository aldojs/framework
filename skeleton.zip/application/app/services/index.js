
'use strict'

let paths = [
  // load the configuration first (required)
  './config',

  // load app file systems (required by logger, session)
  './storage',

  // load global logger (optional)
  './logger',

  // cookie parsing service (required by session)
  './cookies',

  // init session (optional, could be required by auth)
  './session',

  // (optional)
  // './auth',

  // load the app routes (optional)
  './routes'
]

// export
module.exports = paths.map(require)
