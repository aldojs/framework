
// import dependencies

export function install (app) {
  // set up any logger you need
  // app.make('config').get('logger', {})
  // app.bind('logger', () => new Logger())
}
