
import { join } from 'path'
import requireAll from 'require-all'

export function install (app) {
  let routers = requireAll(join(__dirname, '../routes'))

  // load all routes
  for (let namespace in routers) {
    app.use(routers[namespace])
  }

  // add the error responder
  app.catch(_respond)

  // add the error reporter
  app.catch(_report)
}

/**
 * Set the error response
 *
 * @param {Context} ctx
 * @param {Function} next
 * @private
 */
function _respond ({ error, response }, next) {
  // ENOENT support
  if (error.code === 'ENOENT') error.status = 404

  // default to 500
  if (typeof error.status !== 'number') error.status = 500

  // response
  response.status = error.status
  response.set(error.headers || {})
  response.body = error.expose ? error.message : 'Internal Error'

  next()
}

/**
 * Report the error
 *
 * @param {Context} ctx
 * @param {Function} next
 * @private
 */
function _report ({ error }, next) {
  if (error.status !== 404) {
    let msg = error.stack || error.toString()

    console.error()
    console.error(msg.replace(/^/gm, '  '))
    console.error()
  }

  next()
}
