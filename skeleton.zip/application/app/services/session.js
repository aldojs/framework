
import { MemoryDriver, Session } from '@aldo/session'

export function install (app) {
  let config = app.get('config')

  // check if the session service is enabled
  if (config.disabled('session')) return

  // session options
  let { lifetime, cookie, driver: options } = config.get('session')

  // create the default session driver
  let storage = _createStorageDriver(options, app)

  // bind a session factory
  app.bind('session', ({ cookies }) => {
    return new Session({ id: cookies.get(cookie.name), storage, lifetime })
  })

  // use the session middleware
  app.use(async ({ session, cookies }, next) => {
    try {
      // load the session state from the storage
      await session.start()

      // await for response construction
      var response = await next()

      // write the session cookie
      cookies.set(cookie.name, value, cookie).maxAge(lifetime)
  
      return response
    }
    finally {
      // save the session state into the storage
      await session.commit()
    }
  })
}

function _createStorageDriver ({ type }, container) {
  switch (type) {
    case 'memory':
      return // use the default memory store
  }

  throw new TypeError('Invalid session storage type')
}

function _writeCookie (cookies, value, lifetime, options) {
  cookies.set(options.name, value, options).maxAge(lifetime)

  // if (typeof cookie.secure == 'boolean') c.secure(cookie.secure)

  // if (cookie.sameSite !== undefined) c.sameSite(cookie.sameSite)

  // if (typeof cookie.domain == 'string') c.domain(cookie.domain)

  // if (typeof cookie.path == 'string') c.path(cookie.path)
}
