
import { Storage, createDisk } from '@aldo/filesystem'

/**
 * service initializer
 * 
 * @param {Application} app
 */
module.exports = function initialize (app) {
  const config = app.get('config')

  // check if the storage module is enabled
  if (config.disabled('storage')) return

  const manager = new Storage()
  const options = config.get('storage')
  const disks = options.disks || {}

  for (let key in disks || {}) {
    let instance = createDisk(disks[key])

    // debug(`add storage disk: ${key}`)
    manager.set(key, instance, key === options.default)
  }

  app.set('storage', manager)
}
