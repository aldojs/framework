
import { createServer } from '@aldo/http'
import { createApplication } from './app'

const { PORT = 8000 } = process.env

(async () => {
  try {
    let app = await createApplication()
    let server = createServer(app)

    // listening
    await server.start(PORT)

    console.log(`Server up and running on port ${PORT}`)
  } catch (err) {
    console.error(err)
  }
})()
